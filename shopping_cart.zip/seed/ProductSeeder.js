var Product=require('../models/product');
var mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/shopping',{useNewUrlParser:true});


var products = [
        new Product({
        imagePath:'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6823564/2019/2/19/041c2255-93dc-4ced-86bc-42be244d1f121550577636005-Border-Print-Dress-With-Smocking-At-Bust-6831550577634458-1.jpg',
        title:'dress',
        description:'great biba dress with cotton !!!',
        price:850
    }),
    new Product({
        imagePath:'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6742060/2019/3/7/7d4aa5c2-2125-4f01-a36d-f4a195a1a7a11551943241315-Vishudh-Women-Mustard-Printed-A-Line-Kurta-5631551943239922-1.jpg',
        title:'dress',
        description:'wonderfull w branded dress  !!!',
        price:1520
    }),
    new Product({
        imagePath:'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/1959685/2018/4/13/11523618856320-Vishudh-Women-Navy-Blue-Printed-Anarkali-Kurta-5201523618856141-1.jpg',
        title:'dress',
        description:'fablous suit!!!',
        price:1800
    }),
    new Product({
        imagePath:'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/2240930/2017/12/6/11512544767485-Nayo-Women-Maroon-Printed-Anarkali-Kurta-6311512544767362-1.jpg',
        title:'dress',
        description:'great dress!!!',
        price:12
    }),
    new Product({
        imagePath:'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/2329502/2017/12/12/11513075473636-na-1991513075473475-1.jpg',
        title:'dress',
        description:'nice dress with a embroidery!!!',
        price:1601
    }),
    new Product({
        imagePath:'https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/2120587/2018/11/16/16f9e336-ab0c-4b68-9ff9-fa5f086f5f361542345592107-Biba-Women-Red-Embellished-Straight-Kurta-5421542345591795-1.jpg',
        title:'dress',
        description:'beautiful dress with a neetted work!!!',
        price:12
    })
];
    
var done=0;
for(var i=0;i<products.length;i++)
{
products[i].save(function(err,result)
{
done++;
if(done==products.length)
{
exit();
}
});
}
function exit()
{
mongoose.disconnect();
}
